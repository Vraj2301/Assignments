
//------------------------------------------------------------
// Assignment 1 
// Written by: Vraj Patel (40155059)
//For COMP 248 Section AI(lab) AAAE(Tutorial)
//-------------------------------------------------------------
public class Question1 
{
	public static void main(String[] args)
	{	
		// display multiple lines using one System.out.println and use \n to go to next line 
		System.out.println(" Welcome to COMP248 Java programming!" + "\n" + "\n" + 
	                        "Here is the evaluation scheme:" + "\n" + 
				            "- 3 assignments (5% + 6% + 7%)"+ "\n" +
				            "- 7 labs (12% - best 6 out of 7)" + "\n" +
				            "- term test (25%)" + "\n" +
				            "- final (45%)" + "\n" + "\n" +
				            "Please note:" +  "\n" + 
				            "1. In order to pass the course you must complete all components of the course." + "\n" + 
	                        "2. There is no standard relationship between percentages and the letter grades assigned." + "\n" + "\n"+
				            "Wish you have a great semester!");

	}

}