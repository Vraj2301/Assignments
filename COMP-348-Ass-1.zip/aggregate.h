

#ifndef MAIN_CPP_AGGREGATE_H
#define MAIN_CPP_AGGREGATE_H

float minF(float *arr, int arrSize);
float maxF(float *arr, int arrSize);
float sumF(float *arr, int arrSize);
float avgF(float arr[], int arrSize);
float pseudo_avg(float arr[], int arrSize);


#endif //MAIN_CPP_AGGREGATE_H
