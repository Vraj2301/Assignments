
public class ShapeImplementation {

}
