import java.util.*;

public interface Printable {
	public void print();

	public static void print(Shape[] toprint) {
		print(toprint);
	}

}
